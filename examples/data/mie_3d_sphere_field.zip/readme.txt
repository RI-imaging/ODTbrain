This archive contains near-field scattering data for a sphere using the
mie solution. The data was created using the fortran code GMM-field, available
at https://code.google.com/p/scatterlib/wiki/Nearfield.

References:

R. Moritz. Plasmonische Nahfeldresonatoren aus zwei biokonjugierten Goldnanopartikeln.
Doktorarbeit, LMU München (2008).

M. Ringler, A. Schwemer, M. Wunderlich, A. Nichtl, K. Kürzinger, T. A. Klar und
J. Feldmann. Shaping Emission Spectra of Fluorescent Molecules with Single
Plasmonic Nanoresonators. Phys. Rev. Lett. 100, 203002 (2008).
