This archive contains finite difference time domain simulation results
created with the meep package. The data is background corrected.
